package com.winterarc.tracker

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private val tasks = arrayOf("Workout / Exercise","Study Session","Drink Enough Water","No Unnecessary Scrolling","Sleep on Time")
    private var day = 2
    private var completedDays = 1
    private var done = BooleanArray(5)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("winter_arc", Context.MODE_PRIVATE)
        day = prefs.getInt("day",2); completedDays = prefs.getInt("completed",1)
        for(i in 0..4) done[i]=prefs.getBoolean("t$i",false)
        build()
    }

    private fun save(){
        val e=prefs.edit().putInt("day",day).putInt("completed",completedDays)
        for(i in 0..4)e.putBoolean("t$i",done[i])
        e.apply()
    }

    private fun build(){
        val scroll=ScrollView(this)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,28,24,40);setBackgroundColor(Color.rgb(7,17,31))}
        scroll.addView(box)
        fun text(s:String,size:Float,bold:Boolean=false):TextView=TextView(this).apply{
            text=s; textSize=size; setTextColor(Color.rgb(238,246,255)); if(bold)typeface=Typeface.DEFAULT_BOLD
            setPadding(0,8,0,8)
        }
        box.addView(text("❄️ Winter Arc Tracker",32f,true))
        box.addView(text("Consistency over perfection. One day at a time.",15f))
        val status=text("Day $day • ${if(done.all{it})"Ready to Submit" else "In Progress"}",16f,true)
        status.setTextColor(Color.rgb(142,208,255)); box.addView(status)

        val stats=text("CURRENT DAY     TASKS DONE     PROGRESS     COMPLETED DAYS\n$day                 ${done.count{it}}/5              ${done.count{it}*20}%              $completedDays",17f,true)
        box.addView(stats); box.addView(text("Today's Tasks 🎯",23f,true))

        val checks=ArrayList<CheckBox>()
        tasks.forEachIndexed{ i,t ->
            val cb=CheckBox(this).apply{text=t;textSize=16f;setTextColor(Color.WHITE);isChecked=done[i]}
            cb.setOnCheckedChangeListener{_,v->done[i]=v;save(); build()}
            checks.add(cb);box.addView(cb)
        }
        val submit=Button(this).apply{text="Submit Day ✅";isEnabled=done.all{it}}
        submit.setOnClickListener{
            completedDays++; day++; done=BooleanArray(5); save()
            Toast.makeText(this,"🔥 Day submitted! Next day unlocked.",Toast.LENGTH_SHORT).show(); build()
        }
        box.addView(submit)
        val reset=Button(this).apply{text="Reset Today"}
        reset.setOnClickListener{done=BooleanArray(5);save();build()}
        box.addView(reset)
        box.addView(text("📊 Progress Preview",23f,true))
        box.addView(text("Day 1  •  100% completed\nDay $day  •  ${done.count{it}*20}% completed",16f))
        setContentView(scroll)
    }
}