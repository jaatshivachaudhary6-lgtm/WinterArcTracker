# Winter Arc Tracker — Android Studio Project

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated APK on your Android phone.
5. Send the APK to your friend via WhatsApp/Telegram.

The app stores each user's progress locally on their phone.
